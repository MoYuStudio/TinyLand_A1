
--- THANK U -----------------

Thank you for downloading this cardbox asset pack :) hope you like it and find it usefull
This project was originally made as independent, but during the process i liked it and now i'm working on a cardboard castles pack, comming in the near future. Also idk when but will make a full isometric tileset
follow me on itch.io to see the updates. @danimaccari -> https://dani-maccari.itch.io/


--- HOW TO USE --------------

The pack contains 25 tiles (5x5 grid)

Each Box is 18x18 pixels

Box specifications:
	each box is 10 pixels tall
	the base is 16p width x 9p height
	each lateral face is 8p width x 10p height

Conteins 2 extra files:
	box pointer, can be used as a selector or cursor in a videogame
	and a shadow (don't know if it is compatible with autotiling)


--- LICENSE ----------------

This pack is free for personal or comercial use as long as it's atributed to DANI MACCARI.
You are free to edit the sprites as much as you want.
You may not repackage, redistribute or resell the assets, no matter how much they are modified. - This includes NFTs.